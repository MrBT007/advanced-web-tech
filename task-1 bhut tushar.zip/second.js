tushar = {
    name : "Tushar",
    age : 20,
    rollno : "20BCP023"
}

console.log(tushar)