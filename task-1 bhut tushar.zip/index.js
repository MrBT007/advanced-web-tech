const m = require("./second")
console.log("Hello World")
console.log(m)